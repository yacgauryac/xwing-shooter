"""
Player — Le X-Wing du joueur.
Modèle procédural (géométrie de base) + contrôle souris.
"""

from panda3d.core import (
    Vec3, Vec4, Point3,
    GeomVertexFormat, GeomVertexData, GeomVertexWriter,
    Geom, GeomTriangles, GeomNode,
    NodePath, LineSegs
)
import math


class Player:
    """Gère le vaisseau du joueur et ses contrôles."""

    # Limites de déplacement (le vaisseau reste dans le cadre)
    BOUNDS_X = 8.0
    BOUNDS_Z = 5.0

    # Sensibilité souris
    MOUSE_SPEED = 15.0

    # Inclinaison max quand on tourne (en degrés)
    MAX_ROLL = 35.0
    MAX_PITCH = 15.0

    def __init__(self, game):
        self.game = game

        # Position cible (où la souris pointe)
        self.target_x = 0.0
        self.target_z = 0.0

        # Crée le modèle du vaisseau
        self.node = self.create_xwing()
        self.node.reparentTo(game.render)
        self.node.setPos(0, 20, 0)

        # Place la caméra derrière le vaisseau
        game.camera.setPos(0, -5, 3)
        game.camera.lookAt(0, 20, 0)

    def create_xwing(self):
        """
        Crée un X-Wing procédural avec des formes de base.
        C'est moche mais ça marche — on remplacera par un vrai modèle plus tard.
        """
        root = NodePath("xwing")

        # --- Fuselage (corps principal) ---
        fuselage = self.make_box(2.0, 0.4, 0.3, Vec4(0.85, 0.85, 0.85, 1))
        fuselage.reparentTo(root)

        # --- Cockpit (nez) ---
        nose = self.make_box(0.8, 0.3, 0.25, Vec4(0.7, 0.7, 0.75, 1))
        nose.reparentTo(root)
        nose.setPos(1.2, 0, 0.05)

        # --- Ailes (4 ailes en X) ---
        wing_color = Vec4(0.8, 0.8, 0.8, 1)
        wing_red = Vec4(0.9, 0.2, 0.2, 1)

        # Aile haut-droite
        w1 = self.make_box(1.5, 0.05, 0.6, wing_color)
        w1.reparentTo(root)
        w1.setPos(-0.2, 0.25, 0.5)
        # Bande rouge
        r1 = self.make_box(1.5, 0.06, 0.05, wing_red)
        r1.reparentTo(w1)
        r1.setPos(0, 0, 0.25)

        # Aile bas-droite
        w2 = self.make_box(1.5, 0.05, 0.6, wing_color)
        w2.reparentTo(root)
        w2.setPos(-0.2, 0.25, -0.5)
        r2 = self.make_box(1.5, 0.06, 0.05, wing_red)
        r2.reparentTo(w2)
        r2.setPos(0, 0, -0.25)

        # Aile haut-gauche
        w3 = self.make_box(1.5, 0.05, 0.6, wing_color)
        w3.reparentTo(root)
        w3.setPos(-0.2, -0.25, 0.5)
        r3 = self.make_box(1.5, 0.06, 0.05, wing_red)
        r3.reparentTo(w3)
        r3.setPos(0, 0, 0.25)

        # Aile bas-gauche
        w4 = self.make_box(1.5, 0.05, 0.6, wing_color)
        w4.reparentTo(root)
        w4.setPos(-0.2, -0.25, -0.5)
        r4 = self.make_box(1.5, 0.06, 0.05, wing_red)
        r4.reparentTo(w4)
        r4.setPos(0, 0, -0.25)

        # --- Canons (bouts des ailes) ---
        cannon_color = Vec4(0.5, 0.5, 0.55, 1)
        for y_off, z_off in [(0.25, 0.5), (0.25, -0.5), (-0.25, 0.5), (-0.25, -0.5)]:
            cannon = self.make_box(0.6, 0.06, 0.06, cannon_color)
            cannon.reparentTo(root)
            cannon.setPos(1.0, y_off, z_off)

        # --- Réacteurs (arrière) ---
        reactor_color = Vec4(0.3, 0.5, 0.9, 1)
        for y_off in [-0.15, 0.15]:
            reactor = self.make_box(0.15, 0.12, 0.12, reactor_color)
            reactor.reparentTo(root)
            reactor.setPos(-1.1, y_off, 0)

        # Orientation : le vaisseau avance vers +X, on le tourne vers +Y
        root.setH(-90)

        return root

    def make_box(self, sx, sy, sz, color):
        """Crée un pavé (boîte) coloré centré à l'origine."""
        fmt = GeomVertexFormat.getV3c4()
        vdata = GeomVertexData("box", fmt, Geom.UHStatic)

        vertex = GeomVertexWriter(vdata, "vertex")
        col = GeomVertexWriter(vdata, "color")

        hx, hy, hz = sx / 2, sy / 2, sz / 2

        # 8 sommets d'un cube
        corners = [
            (-hx, -hy, -hz), (hx, -hy, -hz), (hx, hy, -hz), (-hx, hy, -hz),
            (-hx, -hy, hz), (hx, -hy, hz), (hx, hy, hz), (-hx, hy, hz),
        ]
        for c in corners:
            vertex.addData3(*c)
            col.addData4(color)

        # 12 triangles (2 par face)
        tris = GeomTriangles(Geom.UHStatic)
        faces = [
            (0, 1, 2), (0, 2, 3),  # bas
            (4, 6, 5), (4, 7, 6),  # haut
            (0, 4, 5), (0, 5, 1),  # avant
            (2, 6, 7), (2, 7, 3),  # arrière
            (0, 3, 7), (0, 7, 4),  # gauche
            (1, 5, 6), (1, 6, 2),  # droite
        ]
        for f in faces:
            tris.addVertices(*f)

        geom = Geom(vdata)
        geom.addPrimitive(tris)

        node = GeomNode("box")
        node.addGeom(geom)

        return NodePath(node)

    def update(self, dt):
        """Met à jour la position du vaisseau selon la souris."""
        # Récupère le mouvement souris (mode relatif)
        md = self.game.win.getPointer(0)

        if self.game.mouseWatcherNode.hasMouse():
            # En mode relatif, on récupère le delta depuis le centre
            mouse_x = self.game.mouseWatcherNode.getMouseX()
            mouse_y = self.game.mouseWatcherNode.getMouseY()

            # Calcule la position cible
            self.target_x = mouse_x * self.BOUNDS_X
            self.target_z = mouse_y * self.BOUNDS_Z

        # Interpole doucement vers la cible (smooth)
        current_pos = self.node.getPos()
        lerp_speed = 5.0 * dt

        new_x = current_pos.getX()  # pas de mouvement latéral sur X (c'est l'axe avant)
        new_y = current_pos.getY()
        # Dans Panda3D : Y = profondeur, X = gauche/droite, Z = haut/bas
        # Mais notre vaisseau est tourné, donc on mappe :
        # souris X -> déplacement sur X du monde
        # souris Y -> déplacement sur Z du monde

        # En fait avec la rotation de -90, on ajuste :
        target_pos = Point3(self.target_x, 20, self.target_z)
        new_pos = current_pos + (target_pos - current_pos) * lerp_speed

        self.node.setPos(new_pos)

        # Inclinaison du vaisseau selon le mouvement
        dx = target_pos.getX() - current_pos.getX()
        dz = target_pos.getZ() - current_pos.getZ()

        target_roll = -dx * self.MAX_ROLL
        target_pitch = dz * self.MAX_PITCH

        # Smooth sur la rotation aussi
        current_r = self.node.getR()
        current_p = self.node.getP()

        self.node.setR(current_r + (target_roll - current_r) * lerp_speed)
        self.node.setP(current_p + (target_pitch - current_p) * lerp_speed)
